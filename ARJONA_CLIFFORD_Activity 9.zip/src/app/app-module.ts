import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { App } from './app';
import { Header } from './header/header';
import { Footer } from './footer/footer';
import { Sidebar } from './sidebar/sidebar';
import { Landing } from './landing/landing';
import { GymDetail } from './gym-detail/gym-detail';
import { TrainerForm } from './trainer-form/trainer-form';

@NgModule({
  declarations: [
    App,
    Header,
    Footer,
    Sidebar,
    Landing,
    GymDetail,
    TrainerForm
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      { path: '', component: Landing },
      { path: 'gym/:id', component: GymDetail },
      { path: 'trainer', component: TrainerForm },
      { path: '**', redirectTo: '' }
    ])
  ],
  providers: [],
  bootstrap: [App]
})
export class AppModule {}
