import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Koga } from './koga';

describe('Koga', () => {
  let component: Koga;
  let fixture: ComponentFixture<Koga>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Koga]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Koga);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
