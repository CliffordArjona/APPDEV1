import { Component } from '@angular/core';
import { KogaService } from '../koga-service';

@Component({
  selector: 'app-koga',
  standalone: false,
  templateUrl: './koga.html'
})
export class Koga {
  koga: any;
  pokemons: any[] = [];
  currentIndex: number = 0;
  currentPokemon: any;

  constructor(private kogaService: KogaService) {
    this.koga = this.kogaService.getKogaInfo();
    this.pokemons = [
      this.kogaService.getAriados(),
      this.kogaService.getVenomoth(),
      this.kogaService.getForretress(),
      this.kogaService.getMuk(),
      this.kogaService.getCrobat()
    ];
    this.currentPokemon = this.pokemons[this.currentIndex];
  }

  next() {
    if (this.currentIndex < this.pokemons.length - 1) {
      this.currentIndex++;
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  }

  previous() {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  }
}
