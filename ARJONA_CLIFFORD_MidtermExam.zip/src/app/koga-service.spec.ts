import { TestBed } from '@angular/core/testing';

import { KogaService } from './koga-service';

describe('KogaService', () => {
  let service: KogaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(KogaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
