import { Component } from '@angular/core';

@Component({
  selector: 'app-review',
  standalone: false,
  templateUrl: './review.html'
})
export class Review {
  reviews: string[] = [];
  newReview: string = '';

  submitReview() {
    if (this.newReview.trim() !== '') {
      this.reviews.push(this.newReview);
      this.newReview = '';
    }
  }
}
