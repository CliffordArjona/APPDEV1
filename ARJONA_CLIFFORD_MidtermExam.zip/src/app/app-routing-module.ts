import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Koga } from './koga/koga';
import { Review } from './review/review';

const routes: Routes = [
  { path: '', redirectTo: 'koga', pathMatch: 'full' },
  { path: 'koga', component: Koga },
  { path: 'review', component: Review }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
