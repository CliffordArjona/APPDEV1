import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class KogaService {
  getKogaInfo() {
    return {
      name: 'Koga',
      title: 'Fuchsia City Gym Leader',
      description: 'Koga, known as the Poisonous Ninja Master, served as a Gym Leader of the Fuchsia Gym and an Elite Four member.'
    };
  }
  
  getAriados() {
    return {
      name: 'Ariados',
      type: 'Bug/Poison',
      hp: 70,
      attack: 90,
      defense: 70,
      spAttack: 60,
      spDefense: 70,
      speed: 40,
      abilities: ['Swarm', 'Insomnia'],
      moves: ["Spider Web", "Baton Pass", "Giga Drain", "Poison Jab"],
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/168.png'
    };
  }

  getForretress() {
    return {
      name: 'Forretress',
      type: 'Bug/Steel',
      hp: 75,
      attack: 90,
      defense: 140,
      spAttack: 60,
      spDefense: 60,
      speed: 40,
      abilities: ['Sturdy', 'Overcoat'],
      moves: ["Swift", "Explosion", "Protect", "Toxic Spikes"],
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/205.png'
    };
  }

  getMuk() {
    return {
      name: 'Muk',
      type: 'Poison',
      hp: 105,
      attack: 105,
      defense: 75,
      spAttack: 65,
      spDefense: 100,
      speed: 50,
      abilities: ['Stench', 'Sticky Hold'],
      moves: ["Gunk Shot", "Minimize", "Screech", "Toxic"],
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/89.png'
    };
  }

  getVenomoth() {
    return {
      name: 'Venomoth',
      type: 'Bug/Poison',
      hp: 70,
      attack: 65,
      defense: 60,
      spAttack: 90,
      spDefense: 75,
      speed: 90,
      abilities: ['Shield Dust', 'Tinted Lens'],
      moves: ["Psychic", "Gust", "Supersonic", "Toxic"],
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/49.png'
    };
  }


  getCrobat() {
    return {
      name: 'Crobat',
      type: 'Poison/Flying',
      hp: 85,
      attack: 90,
      defense: 80,
      spAttack: 70,
      spDefense: 80,
      speed: 130,
      abilities: ['Inner Focus', 'Infiltrator'],
      moves: ["Quick Attack", "Wing Attack", "Double Team" , "Poison Fang"],
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/169.png'
    };
  }
}
