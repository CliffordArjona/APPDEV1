import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { MatDividerModule } from '@angular/material/divider';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { Koga } from './koga/koga';
import { Review } from './review/review';
@NgModule({
  declarations: [
    App,
    Koga,
    Review
  ],
  imports: [
    BrowserModule,
    FormsModule,
    MatDividerModule,
    AppRoutingModule
  ],
  providers: [
    provideBrowserGlobalErrorListeners()
  ],
  bootstrap: [App]
})
export class AppModule { }
