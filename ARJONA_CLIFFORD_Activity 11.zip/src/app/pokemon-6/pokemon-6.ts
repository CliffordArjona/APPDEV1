import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-pokemon-6',
  standalone: false,
  templateUrl: './pokemon-6.html',
  styleUrls: ['./pokemon-6.css']
})
export class Pokemon6 {
  pokemon: any;

  constructor(private http: HttpClient) {
    this.http.get('https://pokeapi.co/api/v2/pokemon/Xatu').subscribe(
      response => {
        this.pokemon = response;
      },
      error => {
        console.error('Error:', error);
      }
    );
  }
}
