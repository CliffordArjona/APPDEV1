import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Pokemon6 } from './pokemon-6';

describe('Pokemon6', () => {
  let component: Pokemon6;
  let fixture: ComponentFixture<Pokemon6>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Pokemon6]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Pokemon6);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
