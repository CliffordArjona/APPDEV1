import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Pokemon3 } from './pokemon-3';

describe('Pokemon3', () => {
  let component: Pokemon3;
  let fixture: ComponentFixture<Pokemon3>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Pokemon3]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Pokemon3);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
