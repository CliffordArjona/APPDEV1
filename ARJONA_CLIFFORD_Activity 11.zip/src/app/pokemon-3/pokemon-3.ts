import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-pokemon-3',
  standalone: false,
  templateUrl: './pokemon-3.html',
  styleUrls: ['./pokemon-3.css']
})
export class Pokemon3 {
  pokemon: any;

  constructor(private http: HttpClient) {
    this.http.get('https://pokeapi.co/api/v2/pokemon/feraligatr').subscribe(
      response => {
        this.pokemon = response;
      },
      error => {
        console.error('Error:', error);
      }
    );
  }
}
