import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Pokemon2 } from './pokemon-2';

describe('Pokemon2', () => {
  let component: Pokemon2;
  let fixture: ComponentFixture<Pokemon2>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Pokemon2]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Pokemon2);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
