import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-pokemon-2',
  standalone: false,
  templateUrl: './pokemon-2.html',
  styleUrls: ['./pokemon-2.css']
})
export class Pokemon2 {
  pokemon: any;

  constructor(private http: HttpClient) {
    this.http.get('https://pokeapi.co/api/v2/pokemon/Ampharos').subscribe(
      response => {
        this.pokemon = response;
      },
      error => {
        console.error('Error:', error);
      }
    );
  }
}
