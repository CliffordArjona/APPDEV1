import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Pokemon1 } from './pokemon-1';

describe('Pokemon1', () => {
  let component: Pokemon1;
  let fixture: ComponentFixture<Pokemon1>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Pokemon1]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Pokemon1);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
