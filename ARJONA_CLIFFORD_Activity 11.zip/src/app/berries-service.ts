import { Injectable } from '@angular/core';

export interface Berry {
  name: string;
  effect: string;
  location: string;
  image: string;
}

@Injectable({
  providedIn: 'root'
})
export class BerriesService {
  getBerries(): Berry[] {
    return [
      {
        name: 'Cheri Berry',
        effect: 'Cures paralysis when held or used.',
        location: 'Violet City berry trees',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/cheri-berry.png'
      },
      {
        name: 'Chesto Berry',
        effect: 'Cures sleep when held or used.',
        location: 'Route 30 / Violet City berry trees',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/chesto-berry.png'
      },
      {
        name: 'Pecha Berry',
        effect: 'Cures poison when held or used.',
        location: 'Azalea Town berry trees',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/pecha-berry.png'
      },
      {
        name: 'Rawst Berry',
        effect: 'Cures burn when held or used.',
        location: 'Route 37 berry trees',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rawst-berry.png'
      },
      {
        name: 'Aspear Berry',
        effect: 'Cures freeze when held or used.',
        location: 'Ecruteak City / berry trees',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/aspear-berry.png'
      },
      {
        name: 'Leppa Berry',
        effect: 'Restores 10 PP when used.',
        location: 'Route 31 berry trees',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/leppa-berry.png'
      },
      {
        name: 'Oran Berry',
        effect: 'Restores 10 HP when eaten.',
        location: 'Common on many routes / shops',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/oran-berry.png'
      },
      {
        name: 'Persim Berry',
        effect: 'Cures confusion when held or used.',
        location: 'Mahogany Town berry trees',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/persim-berry.png'
      },
      {
        name: 'Sitrus Berry',
        effect: 'Restores 25% of max HP.',
        location: 'Route 44 / Goldenrod area',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/sitrus-berry.png'
      },
      {
        name: 'Lum Berry',
        effect: 'Cures any status condition when held.',
        location: 'Rare; found or as reward',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/lum-berry.png'
      },
      {
        name: 'Figy Berry',
        effect: 'Restores 50% HP but may confuse.',
        location: 'Goldenrod Underground or special blends',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/figy-berry.png'
      },
      {
        name: 'Wiki Berry',
        effect: 'Restores 50% HP but may confuse.',
        location: 'Berry blending reward or rare tree',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/wiki-berry.png'
      },
      {
        name: 'Mago Berry',
        effect: 'Restores 50% HP but may confuse.',
        location: 'Rare / special berry tree',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/mago-berry.png'
      },
      {
        name: 'Aguav Berry',
        effect: 'Restores 50% HP but may confuse.',
        location: 'Mt. Silver or remote tree',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/aguav-berry.png'
      },
      {
        name: 'Iapapa Berry',
        effect: 'Restores 50% HP but may confuse.',
        location: 'Lake of Rage / east areas',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/iapapa-berry.png'
      }
    ];
  }
}
