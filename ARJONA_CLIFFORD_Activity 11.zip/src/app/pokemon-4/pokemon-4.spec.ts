import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Pokemon4 } from './pokemon-4';

describe('Pokemon4', () => {
  let component: Pokemon4;
  let fixture: ComponentFixture<Pokemon4>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Pokemon4]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Pokemon4);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
