import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatDividerModule } from '@angular/material/divider'; // ✅ Material Divider

// Components
import { App } from './app';
import { Header } from './header/header';
import { Footer } from './footer/footer';
import { Sidebar } from './sidebar/sidebar';
import { Landing } from './landing/landing';
import { GymDetail } from './gym-detail/gym-detail';
import { TrainerForm } from './trainer-form/trainer-form';
import { Berries } from './berries/berries';
import { Pokeballs } from './pokeballs/pokeballs';

// Pokémon Components
import { Pokemon1 } from './pokemon-1/pokemon-1';
import { Pokemon2 } from './pokemon-2/pokemon-2';
import { Pokemon3 } from './pokemon-3/pokemon-3';
import { Pokemon4 } from './pokemon-4/pokemon-4';
import { Pokemon5 } from './pokemon-5/pokemon-5';
import { Pokemon6 } from './pokemon-6/pokemon-6';
import { AllPokemon } from './all-pokemon/all-pokemon';

@NgModule({
  declarations: [
    App,
    Header,
    Footer,
    Sidebar,
    Landing,
    GymDetail,
    TrainerForm,
    Berries,
    Pokeballs,
    Pokemon1,
    Pokemon2,
    Pokemon3,
    Pokemon4,
    Pokemon5,
    Pokemon6,
    AllPokemon
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatTableModule,
    MatDividerModule,
    RouterModule.forRoot([
      { path: '', component: Landing },
      { path: 'gym/:id', component: GymDetail },
      { path: 'trainer', component: TrainerForm },
      { path: 'berries', component: Berries },
      { path: 'pokeballs', component: Pokeballs },
      { path: 'pokemon-1', component: Pokemon1 },
      { path: 'pokemon-2', component: Pokemon2 },
      { path: 'pokemon-3', component: Pokemon3 },
      { path: 'pokemon-4', component: Pokemon4 },
      { path: 'pokemon-5', component: Pokemon5 },
      { path: 'pokemon-6', component: Pokemon6 },
      { path: 'all-pokemon', component: AllPokemon },
      { path: '**', redirectTo: '' }
    ])
  ],
  bootstrap: [App]
})
export class AppModule {}
