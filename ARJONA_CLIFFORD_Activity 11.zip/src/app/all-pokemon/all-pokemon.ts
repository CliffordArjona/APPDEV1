import { Component } from '@angular/core';
@Component({
  selector: 'app-all-pokemon',
  standalone: false,
  templateUrl: './all-pokemon.html',
  styleUrls: ['./all-pokemon.css']
})
export class AllPokemon {}
