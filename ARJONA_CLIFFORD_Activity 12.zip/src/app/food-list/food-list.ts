import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { MatDividerModule } from '@angular/material/divider';

@Component({
  selector: 'app-food-list',
  standalone: true,
  imports: [CommonModule, MatDividerModule],
  templateUrl: './food-list.html',
  styleUrls: ['./food-list.css'],
})
export class FoodList {
  foods: any[] = [];
  currentIndex: number = 0;
  errorMessage = '';

  private favoriteDishes = [
    'Kentucky Fried Chicken',
    'Jerk chicken with rice & peas',
    'Beef Caldereta',
    'Japanese Katsudon',
    'Spaghetti Bolognese',
    'Nanaimo Bars',
    'Teriyaki Chicken Casserole',
    'Pouding chomeur',
    'Hot and Sour Soup',
    'Syrian Bread'
  ];

  constructor(private http: HttpClient) {
    for (const dish of this.favoriteDishes) {
      this.http.get('https://www.themealdb.com/api/json/v1/1/search.php?s=' + dish).subscribe(
        response => {
          if (response && (response as any).meals && (response as any).meals.length > 0) {
            this.foods.push((response as any).meals[0]);
          }
        },
        error => {
          console.error('Error:', error);
          this.errorMessage = 'Some data could not be loaded.';
        }
      );
    }
  }

  next() {
    this.currentIndex = (this.currentIndex + 1) % this.foods.length;
  }

  prev() {
    this.currentIndex = (this.currentIndex - 1 + this.foods.length) % this.foods.length;
  }
}
