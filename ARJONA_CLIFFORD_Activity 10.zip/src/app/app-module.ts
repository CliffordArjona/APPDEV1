import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule } from '@angular/common';

// Components
import { App } from './app';
import { Header } from './header/header';
import { Footer } from './footer/footer';
import { Sidebar } from './sidebar/sidebar';
import { Landing } from './landing/landing';
import { GymDetail } from './gym-detail/gym-detail';
import { TrainerForm } from './trainer-form/trainer-form';
import { Berries } from './berries/berries';
import { Pokeballs } from './pokeballs/pokeballs';

@NgModule({
  declarations: [
    App,
    Header,
    Footer,
    Sidebar,
    Landing,
    GymDetail,
    TrainerForm,
    Berries,
    Pokeballs
  ],
  imports: [
    BrowserModule,
    CommonModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    MatTableModule,
    RouterModule.forRoot([
      { path: '', component: Landing },
      { path: 'gym/:id', component: GymDetail },
      { path: 'trainer', component: TrainerForm },
      { path: 'berries', component: Berries },
      { path: 'pokeballs', component: Pokeballs },
      { path: '**', redirectTo: '' }
    ])
  ],
  providers: [],
  bootstrap: [App]
})
export class AppModule {}
