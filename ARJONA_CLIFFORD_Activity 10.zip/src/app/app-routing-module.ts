import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Landing } from './landing/landing';
import { GymDetail } from './gym-detail/gym-detail';
import { Berries } from './berries/berries';
import { Pokeballs } from './pokeballs/pokeballs';

const routes: Routes = [
  { path: '', component: Landing },
  { path: 'gym/:id', component: GymDetail },
  { path: 'berries', component: Berries },
  { path: 'pokeballs', component: Pokeballs },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
