import { Component } from '@angular/core';
import { FormArray, FormControl, FormGroup } from '@angular/forms';

type Trainer = {
  name: string;
  age: string;
  address: string;
  pokemonTeam: string[];
};

@Component({
  selector: 'app-trainer-form',
  standalone: false,
  templateUrl: './trainer-form.html',
  styleUrl: './trainer-form.css'
})
export class TrainerForm {
  popupVisible = false;

  trainerList: Trainer[] = [];
  formGroup = new FormGroup({
    name: new FormControl('', { nonNullable: true }),
    age: new FormControl('', { nonNullable: true }),
    address: new FormControl('', { nonNullable: true }),
    pokemonTeam: new FormArray([
      new FormControl(''),
      new FormControl(''),
      new FormControl(''),
      new FormControl(''),
      new FormControl(''),
      new FormControl('')
    ])
  });

  get pokemonTeamControls() {
    return (this.formGroup.get('pokemonTeam') as FormArray).controls;
  }

  togglePopup() {
    this.popupVisible = !this.popupVisible;
  }

  onSubmit() {
    const trainer = this.formGroup.getRawValue();
    const cleanTrainer: Trainer = {
      name: trainer.name ?? '',
      age: trainer.age ?? '',
      address: trainer.address ?? '',
      pokemonTeam: (trainer.pokemonTeam ?? []).map(p => p ?? '')
    };
    this.trainerList.push(cleanTrainer);
    this.formGroup.reset();
    this.popupVisible = false;
  }
}
