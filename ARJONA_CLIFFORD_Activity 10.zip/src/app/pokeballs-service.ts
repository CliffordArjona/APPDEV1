import { Injectable } from '@angular/core';

export interface Pokeball {
  name: string;
  effect: string;
  location: string;
  image: string;
}

@Injectable({
  providedIn: 'root'
})
export class PokeballsService {
  getPokeballs(): Pokeball[] {
    return [
      {
        name: 'Poké Ball',
        effect: 'Standard capture device.',
        location: 'All Poké Marts',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png'
      },
      {
        name: 'Great Ball',
        effect: 'Higher catch rate than Poké Ball.',
        location: 'Goldenrod City Mart',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/great-ball.png'
      },
      {
        name: 'Ultra Ball',
        effect: 'Even higher catch rate.',
        location: 'Blackthorn City Mart',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/ultra-ball.png'
      },
      {
        name: 'Fast Ball',
        effect: 'Works better on Pokémon that flee quickly.',
        location: 'Azalea Town / Kurt',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/fast-ball.png'
      },
      {
        name: 'Heavy Ball',
        effect: 'Better for catching heavier Pokémon.',
        location: 'Azalea Town / Kurt',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/heavy-ball.png'
      },
      {
        name: 'Level Ball',
        effect: 'More effective when your Pokémon’s level is much higher.',
        location: 'Azalea Town / Kurt',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/level-ball.png'
      },
      {
        name: 'Lure Ball',
        effect: 'Better on Pokémon encountered by fishing.',
        location: 'Azalea Town / Kurt',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/lure-ball.png'
      },
      {
        name: 'Love Ball',
        effect: 'Better if wild Pokémon is opposite gender of yours.',
        location: 'Azalea Town / Kurt',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/love-ball.png'
      },
      {
        name: 'Friend Ball',
        effect: 'Makes the caught Pokémon more friendly.',
        location: 'Azalea Town / Kurt',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/friend-ball.png'
      },
      {
        name: 'Luxury Ball',
        effect: 'Increases friendship more if caught.',
        location: 'Goldenrod City Mart',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/luxury-ball.png'
      },
      {
        name: 'Master Ball',
        effect: 'Catches any Pokémon without fail.',
        location: 'Rare prize / gift',
        image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/master-ball.png'
      }
    ];
  }
}
