import { Component } from '@angular/core';
import { BerriesService } from '../berries-service';

@Component({
  selector: 'app-berries',
  standalone: false,
  templateUrl: './berries.html',
  styleUrl: './berries.css'
})
export class Berries {
  dataSource: { name: string; effect: string; location: string; image: string }[] = [];
  displayedColumns: string[] = ['name', 'effect', 'location'];

  constructor(private berriesService: BerriesService) {}

  ngOnInit(): void {
    this.dataSource = this.berriesService.getBerries();
  }
}
