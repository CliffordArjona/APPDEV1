import { Component } from '@angular/core';
import { PokeballsService } from '../pokeballs-service';

@Component({
  selector: 'app-pokeballs',
  standalone: false,
  templateUrl: './pokeballs.html',
  styleUrl: './pokeballs.css'
})
export class Pokeballs {
  dataSource: { name: string; effect: string; location: string; image: string }[] = [];
  displayedColumns: string[] = ['name', 'effect', 'location'];

  constructor(private pokeballsService: PokeballsService) {}

  ngOnInit(): void {
    this.dataSource = this.pokeballsService.getPokeballs();
  }
}
