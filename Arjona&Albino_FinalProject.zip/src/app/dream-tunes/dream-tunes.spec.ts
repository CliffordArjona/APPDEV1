import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DreamTunes } from './dream-tunes';

describe('DreamTunes', () => {
  let component: DreamTunes;
  let fixture: ComponentFixture<DreamTunes>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DreamTunes]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DreamTunes);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
