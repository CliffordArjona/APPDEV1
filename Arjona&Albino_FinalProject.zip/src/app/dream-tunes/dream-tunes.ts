import { Component, OnDestroy, ChangeDetectorRef, NgZone } from '@angular/core';

@Component({
  selector: 'app-dream-tunes',
  standalone: false,
  templateUrl: './dream-tunes.html'
})
export class DreamTunes implements OnDestroy {
  timers = [
    { label: '5 minutes', seconds: 5 * 60 },
    { label: '15 minutes', seconds: 15 * 60 },
    { label: '30 minutes', seconds: 30 * 60 },
    { label: '1 hour', seconds: 60 * 60 }
  ];

  sounds = [
    { 
      id: 'rain', 
      title: 'Gentle Rain', 
      icon: '🌧️',
      description: 'Soft rainfall sounds',
      url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3' 
    },
    { 
      id: 'ocean', 
      title: 'Ocean Waves', 
      icon: '🌊',
      description: 'Calming sea sounds',
      url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3' 
    },
    { 
      id: 'heartbeat', 
      title: 'Heartbeat', 
      icon: '💓',
      description: 'Soothing rhythm',
      url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3' 
    },
    { 
      id: 'white', 
      title: 'White Noise', 
      icon: '📻',
      description: 'Pure white noise',
      url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3' 
    },
    { 
      id: 'forest', 
      title: 'Forest Sounds', 
      icon: '🌲',
      description: 'Birds and nature',
      url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3' 
    },
    { 
      id: 'wind', 
      title: 'Gentle Wind', 
      icon: '🍃',
      description: 'Soft breeze sounds',
      url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3' 
    }
  ];

  selectedSound: any = null;
  audio: HTMLAudioElement | null = null;
  timerId: any = null;
  countdownInterval: any = null;
  remaining = 0;
  activeTimer: number = 0;
  totalTime = 0;
  volume = 0.5;

  constructor(
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone
  ) {}

  selectSound(s: any) {
    this.stop();
    this.selectedSound = s;
    this.audio = new Audio(s.url);
    this.audio.loop = true;
    this.audio.volume = this.volume;
    this.audio.play().catch(err => console.error('Audio play error:', err));
    this.cdr.detectChanges();
  }

  setTimer(seconds: number) {
    if (!this.audio) {
      alert('⚠️ Please select a sound first before setting a timer!');
      return;
    }

    this.clearTimer();
    
    this.activeTimer = seconds;
    this.remaining = seconds;
    this.totalTime = seconds;
    
    // Use NgZone to ensure Angular detects changes from setInterval
    this.ngZone.runOutsideAngular(() => {
      this.countdownInterval = setInterval(() => {
        this.remaining--;
        
        // Run change detection inside Angular zone
        this.ngZone.run(() => {
          this.cdr.detectChanges();
        });
        
        if (this.remaining <= 0) {
          this.ngZone.run(() => {
            this.fadeOutAndStop();
          });
        }
      }, 1000);
    });
    
    // Set timeout to stop
    this.timerId = setTimeout(() => {
      this.fadeOutAndStop();
    }, seconds * 1000);
    
    this.cdr.detectChanges();
  }

  fadeOutAndStop() {
    if (!this.audio) return;
    
    // Fade out effect
    const fadeInterval = setInterval(() => {
      if (this.audio && this.audio.volume > 0.05) {
        this.audio.volume -= 0.05;
      } else {
        clearInterval(fadeInterval);
        this.stop();
      }
    }, 100);
  }

  clearTimer() {
    if (this.timerId) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }
    if (this.countdownInterval) {
      clearInterval(this.countdownInterval);
      this.countdownInterval = null;
    }
    this.remaining = 0;
    this.activeTimer = 0;
    this.totalTime = 0;
    this.cdr.detectChanges();
  }

  stop() {
    if (this.audio) {
      this.audio.pause();
      this.audio.currentTime = 0;
      this.audio = null;
    }
    this.clearTimer();
    this.selectedSound = null;
    this.cdr.detectChanges();
  }

  setVolume(event: any) {
    this.volume = event.target.value / 100;
    if (this.audio) {
      this.audio.volume = this.volume;
    }
    this.cdr.detectChanges();
  }

  formatTime(seconds: number): string {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }

  getProgress(): number {
    if (this.totalTime === 0) return 0;
    return ((this.totalTime - this.remaining) / this.totalTime) * 100;
  }

  ngOnDestroy() {
    this.stop();
  }
}