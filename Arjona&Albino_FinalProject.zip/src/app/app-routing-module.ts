import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { Home } from './home/home';
import { Login } from './login/login';
import { Register } from './register/register';
import { Lullaby } from './lullaby/lullaby';
import { Storybook } from './storybook/storybook';
import { Favourites } from './favourites/favourites';
import { DreamTunes } from './dream-tunes/dream-tunes';
import { Learning } from './learning/learning';
import { Quote } from './quote/quote';
import { Profile } from './profile/profile';

const routes: Routes = [
  { path: '', component: Home },
  { path: 'login', component: Login },
  { path: 'register', component: Register },
  { path: 'lullaby', component: Lullaby, runGuardsAndResolvers: 'always' },
  { path: 'storybook', component: Storybook, runGuardsAndResolvers: 'always' },
  { path: 'favourites', component: Favourites },
  { path: 'dream-tunes', component: DreamTunes },
  { path: 'learning', component: Learning },
  { path: 'quote', component: Quote },
  { path: 'profile', component: Profile },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { onSameUrlNavigation: 'reload' })],
  exports: [RouterModule]
})
export class AppRoutingModule {}