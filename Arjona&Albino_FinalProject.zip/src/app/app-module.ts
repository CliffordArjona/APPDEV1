import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDividerModule } from '@angular/material/divider';

import { App } from './app';
import { AppRoutingModule } from './app-routing-module';

import { Home } from './home/home';
import { Login } from './login/login';
import { Register } from './register/register';
import { Lullaby } from './lullaby/lullaby';
import { Storybook } from './storybook/storybook';
import { Favourites } from './favourites/favourites';
import { DreamTunes } from './dream-tunes/dream-tunes';
import { Learning } from './learning/learning';
import { Quote } from './quote/quote';
import { Profile } from './profile/profile';

@NgModule({
  declarations: [
    App,
    Home,
    Login,
    Register,
    Lullaby,
    Storybook,
    Favourites,
    DreamTunes,
    Learning,
    Quote,
    Profile
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatDividerModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [App]
})
export class AppModule {}
