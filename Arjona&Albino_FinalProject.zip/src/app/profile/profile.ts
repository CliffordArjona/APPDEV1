import { Component } from '@angular/core';
import { AuthService } from '../auth-service';
import { FavoritesService } from '../favorites-service';

@Component({
  selector: 'app-profile',
  standalone: false,
  templateUrl: './profile.html'
})
export class Profile {
  user: any = null;
  favs: any = { lullaby: [], story: [] };

  constructor(private auth: AuthService, private fav: FavoritesService) {
    this.user = auth.getCurrentUser();
    if (this.user) this.favs = fav.list(this.user.username);
  }
}
