import { Injectable } from '@angular/core';
import { of, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class QuoteService {
  private quotes = [
    { text: "A parent's love is whole no matter how many times divided.", author: "Robert Brault" },
    { text: "To a child's ear, 'mother' is magic in any language.", author: "Arlene Benedict" },
    { text: "The days are long, but the years are short.", author: "Gretchen Rubin" },
    { text: "Children are not things to be molded, but are people to be unfolded.", author: "Jess Lair" },
    { text: "A mother's arms are made of tenderness and children sleep soundly in them.", author: "Victor Hugo" },
    { text: "In every child who is born, the potentiality of the human race is born again.", author: "James Agee" },
    { text: "There is no friendship, no love, like that of the parent for the child.", author: "Henry Ward Beecher" },
    { text: "Children see magic because they look for it.", author: "Christopher Moore" },
    { text: "The heart of a mother is a deep abyss at the bottom of which you will always find forgiveness.", author: "Honoré de Balzac" },
    { text: "A person's a person, no matter how small.", author: "Dr. Seuss" },
    { text: "While we try to teach our children all about life, our children teach us what life is all about.", author: "Angela Schwindt" },
    { text: "To be in your children's memories tomorrow, you have to be in their lives today.", author: "Barbara Johnson" },
    { text: "A baby is something you carry inside you for nine months, in your arms for three years, and in your heart until the day you die.", author: "Mary Mason" },
    { text: "The soul is healed by being with children.", author: "Fyodor Dostoevsky" },
    { text: "Children are the anchors that hold a mother to life.", author: "Sophocles" },
    { text: "A child can ask questions that a wise man cannot answer.", author: "Unknown" },
    { text: "Every child comes with the message that God is not yet discouraged of man.", author: "Rabindranath Tagore" },
    { text: "Making the decision to have a child is momentous. It is to decide forever to have your heart go walking around outside your body.", author: "Elizabeth Stone" },
    { text: "We worry about what a child will become tomorrow, yet we forget that he is someone today.", author: "Stacia Tauscher" },
    { text: "The best way to make children good is to make them happy.", author: "Oscar Wilde" },
    { text: "Your children need your presence more than your presents.", author: "Jesse Jackson" },
    { text: "It is easier to build strong children than to repair broken men.", author: "Frederick Douglass" },
    { text: "Children make your life important.", author: "Erma Bombeck" },
    { text: "A child who reads will be an adult who thinks.", author: "Unknown" },
    { text: "Cleaning your house while your kids are still growing is like shoveling the walk before it stops snowing.", author: "Phyllis Diller" },
    { text: "There really are places in the heart you don't even know exist until you love a child.", author: "Anne Lamott" },
    { text: "Never worry about the size of your Christmas tree. In the eyes of children, they are all 30 feet tall.", author: "Larry Wilde" },
    { text: "The best inheritance a parent can give his children is a few minutes of his time each day.", author: "O.A. Battista" },
    { text: "A child is a beam of sunlight from the Infinite and Eternal, with possibilities of virtue and vice, but as yet unstained.", author: "Lyman Abbott" },
    { text: "Sweet dreams are made of love, and love is what parents give.", author: "Unknown" }
  ];
  
  constructor() {}
  
  getRandomQuote(): Observable<any> {
    const randomIndex = Math.floor(Math.random() * this.quotes.length);
    return of(this.quotes[randomIndex]);
  }
}