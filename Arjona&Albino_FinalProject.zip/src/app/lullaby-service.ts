import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, catchError, switchMap } from 'rxjs/operators';
import { of, Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class LullabyService {
  private CLIENT_ID = '391b318e34a9498e8143802a6306312a';
  private CLIENT_SECRET = '36b0dda0f08e4f71b85b28ba6d017dff';
  
  private accessToken: string | null = null;
  private tokenExpiry: number = 0;

  constructor(private http: HttpClient) {}

  private getAccessToken(): Observable<string> {
    if (this.accessToken && Date.now() < this.tokenExpiry) {
      return of(this.accessToken);
    }

    const authString = btoa(`${this.CLIENT_ID}:${this.CLIENT_SECRET}`);
    const headers = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': `Basic ${authString}`
    });

    const body = 'grant_type=client_credentials';

    return this.http.post<any>('https://accounts.spotify.com/api/token', body, { headers }).pipe(
      map((response: any) => {
        this.accessToken = response.access_token;
        // Set expiry to 5 minutes before actual expiry
        this.tokenExpiry = Date.now() + ((response.expires_in - 300) * 1000);
        return this.accessToken!;
      }),
      catchError((err: any) => {
        console.error('Failed to get access token:', err);
        return of('');
      })
    );
  }

  searchLullabies(query: string): Observable<any[]> {
    if (!query || query.length < 2) return of([]);
    
    return this.getAccessToken().pipe(
      switchMap((token: string) => {
        if (!token) {
          console.error('No access token available');
          return of([]);
        }

        const searchQuery = encodeURIComponent(`${query} lullaby`);
        const url = `https://api.spotify.com/v1/search?q=${searchQuery}&type=track&limit=10`;
        
        const headers = new HttpHeaders({
          'Authorization': `Bearer ${token}`
        });

        return this.http.get<any>(url, { headers }).pipe(
          map((response: any) => {
            if (!response || !response.tracks || !response.tracks.items) {
              return [];
            }
            
            return response.tracks.items.map((track: any) => ({
              title: track.name,
              author: track.artists.map((a: any) => a.name).join(', '),
              spotifyId: track.id,
              previewUrl: track.preview_url,
              albumImage: track.album.images[0]?.url,
              spotifyUrl: track.external_urls.spotify
            }));
          }),
          catchError((err: any) => {
            console.error('Spotify search failed:', err);
            return of([]);
          })
        );
      })
    );
  }
}