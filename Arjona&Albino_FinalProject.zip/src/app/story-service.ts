import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, catchError, switchMap } from 'rxjs/operators';
import { of, Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class StoryService {
  constructor(private http: HttpClient) {}

  searchBooks(q: string) {
    if (!q || q.trim().length === 0) return of([]);
    const query = encodeURIComponent(q);
    
    // Add children's book filters
    const url = `https://openlibrary.org/search.json?q=${query}&subject=juvenile%20fiction&subject=children&limit=20`;

    const headers = new HttpHeaders({
      'Accept': 'application/json',
      'User-Agent': 'LittleDreamsApp/1.0 (student@school.edu)'
    });

    return this.http.get<any>(url, { headers }).pipe(
      map(resp => (resp && resp.docs) ? resp.docs : []),
      catchError(err => {
        console.error('StoryService error', err);
        return of([]);
      })
    );
  }

  getBookDetails(workKey: string): Observable<any> {
    if (!workKey) return of(null);
    
    // Remove leading slash if present
    const cleanKey = workKey.startsWith('/works/') ? workKey : `/works/${workKey}`;
    const url = `https://openlibrary.org${cleanKey}.json`;

    const headers = new HttpHeaders({
      'Accept': 'application/json',
      'User-Agent': 'LittleDreamsApp/1.0 (student@school.edu)'
    });

    return this.http.get<any>(url, { headers }).pipe(
      map(resp => {
        if (!resp) return null;
        
        // Extract description - it can be a string or an object with 'value'
        let description = 'No description available';
        if (resp.description) {
          if (typeof resp.description === 'string') {
            description = resp.description;
          } else if (resp.description.value) {
            description = resp.description.value;
          }
        }
        
        return {
          title: resp.title || 'Untitled',
          description: description,
          subjects: resp.subjects || [],
          firstPublishDate: resp.first_publish_date || 'Unknown',
          covers: resp.covers || []
        };
      }),
      catchError(err => {
        console.error('Error fetching book details', err);
        return of(null);
      })
    );
  }
}