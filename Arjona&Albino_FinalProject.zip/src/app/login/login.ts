import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth-service';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.html'
})
export class Login {
  username = '';
  password = '';
  message = '';
  showPassword = false;

  constructor(private auth: AuthService, private router: Router) {}

  togglePassword() {
    this.showPassword = !this.showPassword;
  }

  submit() {
    if (!this.username.trim()) {
      this.message = 'Please enter a username';
      return;
    }
    
    if (!this.password) {
      this.message = 'Please enter a password';
      return;
    }

    const res = this.auth.login(this.username.trim(), this.password);
    this.message = res.message;
    if (res.success) {
      window.dispatchEvent(new Event('storage'));
      this.router.navigate(['/']);
    }
  }
}