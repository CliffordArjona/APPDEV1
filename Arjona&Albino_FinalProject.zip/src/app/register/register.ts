import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth-service';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.html'
})
export class Register {
  username = '';
  password = '';
  confirmPassword = '';
  message = '';
  showPassword = false;
  showConfirmPassword = false;

  constructor(private auth: AuthService, private router: Router) {}

  togglePassword() {
    this.showPassword = !this.showPassword;
  }

  toggleConfirmPassword() {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

  submit() {
    // Validation
    if (!this.username.trim()) {
      this.message = 'Please enter a username';
      return;
    }

    if (this.username.trim().length < 3) {
      this.message = 'Username must be at least 3 characters';
      return;
    }
    
    if (!this.password) {
      this.message = 'Please enter a password';
      return;
    }

    if (this.password.length < 6) {
      this.message = 'Password must be at least 6 characters';
      return;
    }
    
    if (!this.confirmPassword) {
      this.message = 'Please confirm your password';
      return;
    }

    if (this.password !== this.confirmPassword) {
      this.message = 'Passwords do not match';
      return;
    }

    const res = this.auth.register(this.username.trim(), this.password);
    this.message = res.message;
    
    if (res.success) {
      this.auth.login(this.username.trim(), this.password);
      window.dispatchEvent(new Event('storage'));
      
      // Show success message then redirect
      setTimeout(() => {
        this.router.navigate(['/']);
      }, 1500);
    }
  }
}