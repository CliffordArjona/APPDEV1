import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private usersKey = 'ld_users';
  private loggedKey = 'loggedUser';

  private readUsers(): any[] {
    const raw = localStorage.getItem(this.usersKey) || '[]';
    try { return JSON.parse(raw); } catch { return []; }
  }

  register(username: string, password: string) {
    const users = this.readUsers();
    if (users.find(u => u.username === username)) {
      return { success: false, message: 'Username already exists' };
    }
    users.push({ username, password });
    localStorage.setItem(this.usersKey, JSON.stringify(users));
    return { success: true, message: 'Registered successfully' };
  }

  login(username: string, password: string) {
    const users = this.readUsers();
    const found = users.find(u => u.username === username && u.password === password);
    if (!found) return { success: false, message: 'Invalid credentials' };
    localStorage.setItem(this.loggedKey, JSON.stringify({ username }));
    return { success: true, message: 'Logged in' };
  }

  logout() {
    localStorage.removeItem(this.loggedKey);
  }

  getCurrentUser() {
    const raw = localStorage.getItem(this.loggedKey);
    if (!raw) return null;
    try { return JSON.parse(raw); } catch { return null; }
  }
}
