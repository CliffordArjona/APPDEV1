import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learning',
  standalone: false,
  templateUrl: './learning.html'
})
export class Learning implements OnInit {
  alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
  numbers = Array.from({length: 20}, (_, i) => (i + 1).toString());
  
  colors = [
    { name: 'Red', color: '#FF6B6B' },
    { name: 'Blue', color: '#4ECDC4' },
    { name: 'Yellow', color: '#FFE66D' },
    { name: 'Green', color: '#95E1D3' },
    { name: 'Purple', color: '#C7CEEA' },
    { name: 'Orange', color: '#FFBE76' },
    { name: 'Pink', color: '#FFB6C1' },
    { name: 'Brown', color: '#D4A574' }
  ];

  shapes = [
    { name: 'Circle', svg: '<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="40" fill="#FFE66D"/></svg>' },
    { name: 'Square', svg: '<svg viewBox="0 0 100 100"><rect x="15" y="15" width="70" height="70" fill="#4ECDC4"/></svg>' },
    { name: 'Triangle', svg: '<svg viewBox="0 0 100 100"><polygon points="50,15 90,85 10,85" fill="#FF6B6B"/></svg>' },
    { name: 'Star', svg: '<svg viewBox="0 0 100 100"><polygon points="50,10 61,40 95,40 68,60 79,90 50,70 21,90 32,60 5,40 39,40" fill="#FFD93D"/></svg>' }
  ];

  currentMath: any = { question: '', answer: 0, options: [] };
  mathFeedback = '';
  mathMessage = '';

  rhyme = `🌟 One little star shining bright,
🌙 Two little moons in the night,
☁️ Three fluffy clouds floating by,
🦋 Four butterflies in the sky,
🌺 Five pretty flowers in a row,
🌈 Count them all and watch them grow!`;

  ngOnInit() {
    this.generateMath();
  }

  speakLetter(letter: string) {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(letter);
      utterance.rate = 0.8;
      window.speechSynthesis.speak(utterance);
    }
  }

  speakNumber(num: string) {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(num);
      utterance.rate = 0.8;
      window.speechSynthesis.speak(utterance);
    }
  }

  speakColor(color: string) {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(color);
      utterance.rate = 0.8;
      window.speechSynthesis.speak(utterance);
    }
  }

  speakShape(shape: string) {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(shape);
      utterance.rate = 0.8;
      window.speechSynthesis.speak(utterance);
    }
  }

  generateMath() {
    const num1 = Math.floor(Math.random() * 10) + 1;
    const num2 = Math.floor(Math.random() * 10) + 1;
    const operation = Math.random() > 0.5 ? '+' : '-';
    
    let answer = 0;
    let question = '';
    
    if (operation === '+') {
      answer = num1 + num2;
      question = `${num1} + ${num2} = ?`;
    } else {
      if (num1 >= num2) {
        answer = num1 - num2;
        question = `${num1} - ${num2} = ?`;
      } else {
        answer = num2 - num1;
        question = `${num2} - ${num1} = ?`;
      }
    }

    const options = [answer];
    while (options.length < 4) {
      const wrongAnswer = answer + Math.floor(Math.random() * 6) - 3;
      if (wrongAnswer >= 0 && !options.includes(wrongAnswer)) {
        options.push(wrongAnswer);
      }
    }

    this.currentMath = {
      question,
      answer,
      options: options.sort(() => Math.random() - 0.5)
    };

    this.mathFeedback = '';
    this.mathMessage = '';
  }

  checkAnswer(selected: number) {
    if (selected === this.currentMath.answer) {
      this.mathFeedback = 'correct';
      this.mathMessage = '🎉 Correct! Great job!';
      setTimeout(() => this.generateMath(), 1500);
    } else {
      this.mathFeedback = 'wrong';
      this.mathMessage = '❌ Try again!';
      setTimeout(() => {
        this.mathFeedback = '';
        this.mathMessage = '';
      }, 1000);
    }
  }
}