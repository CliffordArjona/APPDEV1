import { Component, OnInit } from '@angular/core';
import { QuoteService } from '../quote-service';

@Component({
  selector: 'app-quote',
  standalone: false,
  templateUrl: './quote.html'
})
export class Quote implements OnInit {
  quote: any = null;
  loading = false;
  
  constructor(private svc: QuoteService) {}
  
  ngOnInit() {
    this.loadRandomQuote();
  }
  
  loadRandomQuote() {
    this.loading = true;
    
    this.svc.getRandomQuote().subscribe({
      next: (q: any) => { 
        this.loading = false;
        this.quote = q;
      },
      error: (err: any) => {
        this.loading = false;
        this.quote = {
          text: "Dream big, sleep tight, tomorrow will be bright.",
          author: "Unknown"
        };
      }
    });
  }
}