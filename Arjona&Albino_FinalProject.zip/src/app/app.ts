import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {
  isLoggedIn = false;
  username = '';

  constructor(private router: Router) {
    this.syncAuth();
    window.addEventListener('storage', () => this.syncAuth());
  }

  syncAuth() {
    const raw = localStorage.getItem('loggedUser');
    if (raw) {
      try {
        const u = JSON.parse(raw);
        this.isLoggedIn = true;
        this.username = u.username || '';
        return;
      } catch {}
    }
    this.isLoggedIn = false;
    this.username = '';
  }

  logout() {
    localStorage.removeItem('loggedUser');
    this.syncAuth();
    this.router.navigate(['/']);
  }
}
