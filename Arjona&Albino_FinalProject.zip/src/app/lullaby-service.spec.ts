import { TestBed } from '@angular/core/testing';

import { LullabyService } from './lullaby-service';

describe('LullabyService', () => {
  let service: LullabyService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LullabyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
