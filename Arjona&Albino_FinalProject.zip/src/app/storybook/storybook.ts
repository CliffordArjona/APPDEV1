import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { StoryService } from '../story-service';
import { FavoritesService } from '../favorites-service';
import { AuthService } from '../auth-service';
import { Router, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-storybook',
  standalone: false,
  templateUrl: './storybook.html'
})
export class Storybook implements OnInit, OnDestroy {
  query = '';
  results: any[] = [];
  message = '';
  selectedBook: any = null;
  loadingDetails = false;
  loadingSearch = false;
  private routerSubscription?: Subscription;

  constructor(
    private svc: StoryService, 
    private fav: FavoritesService,
    private auth: AuthService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    console.log('Storybook component initialized');
    this.loadDefaultBooks();

    // Listen for navigation events to reload when clicking nav again
    this.routerSubscription = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        if (this.router.url === '/storybook' && this.results.length === 0) {
          console.log('Reloading books from navigation');
          this.loadDefaultBooks();
        }
      });
  }

  ngOnDestroy() {
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
  }

  loadDefaultBooks() {
    const words = ['fairy tale', 'princess', 'animal stories', 'adventure', 'magic', 'friendship'];
    const randomWord = words[Math.floor(Math.random() * words.length)];
    
    console.log('Loading default books with query:', randomWord);
    
    this.results = [];
    this.message = '';
    this.loadingSearch = true;
    this.cdr.detectChanges(); // Force UI update
    
    this.svc.searchBooks(randomWord).subscribe({
      next: docs => {
        console.log('Received books:', docs?.length);
        this.loadingSearch = false;
        this.results = (docs || []).slice(0, 20);
        if (this.results.length === 0) {
          this.message = 'No books found. Try searching for something else.';
        }
        this.cdr.detectChanges(); // Force UI update
      },
      error: (err) => {
        console.error('Error loading books:', err);
        this.loadingSearch = false;
        this.results = [];
        this.message = 'Error loading books. Please try again.';
        this.cdr.detectChanges(); // Force UI update
      }
    });
  }

  search() {
    const trimmedQuery = this.query.trim();
    console.log('Search triggered with query:', trimmedQuery);
    
    if (trimmedQuery.length < 2) {
      this.message = 'Type at least 2 characters';
      this.results = [];
      this.cdr.detectChanges();
      return;
    }

    // Immediately clear and show loading
    this.results = [];
    this.message = '';
    this.loadingSearch = true;
    this.cdr.detectChanges(); // Force immediate UI update

    // Small delay to ensure UI updates before API call
    setTimeout(() => {
      this.svc.searchBooks(trimmedQuery).subscribe({
        next: docs => {
          console.log('Search results received:', docs?.length);
          this.loadingSearch = false;
          this.results = (docs || []).slice(0, 20);
          this.message = this.results.length ? '' : 'No books found';
          this.cdr.detectChanges(); // Force UI update
        },
        error: (err) => {
          console.error('Search error:', err);
          this.loadingSearch = false;
          this.results = [];
          this.message = 'API error. Please try again.';
          this.cdr.detectChanges(); // Force UI update
        }
      });
    }, 50);
  }

  viewBook(doc: any) {
    console.log('View book clicked:', doc.title);
    
    if (!doc.key) {
      this.message = 'Cannot load book details';
      this.cdr.detectChanges();
      return;
    }

    // Immediately show loading state
    this.loadingDetails = true;
    this.selectedBook = {
      title: doc.title,
      author_name: doc.author_name,
      cover_i: doc.cover_i,
      key: doc.key,
      description: 'Loading...',
      subjects: []
    };
    document.body.style.overflow = 'hidden';
    this.cdr.detectChanges(); // Force immediate UI update

    // Small delay to ensure popup shows before loading
    setTimeout(() => {
      this.svc.getBookDetails(doc.key).subscribe({
        next: details => {
          console.log('Book details received:', details);
          this.loadingDetails = false;
          if (details) {
            this.selectedBook = {
              ...details,
              key: doc.key,
              author_name: doc.author_name,
              cover_i: doc.cover_i
            };
          } else {
            this.selectedBook.description = 'No description available';
          }
          this.cdr.detectChanges(); // Force UI update
        },
        error: (err) => {
          console.error('Error loading book details:', err);
          this.loadingDetails = false;
          this.selectedBook.description = 'Error loading details. Please try again.';
          this.cdr.detectChanges(); // Force UI update
        }
      });
    }, 100);
  }

  closeBookView() {
    this.selectedBook = null;
    this.loadingDetails = false;
    document.body.style.overflow = 'auto';
    this.cdr.detectChanges();
  }

  getCoverUrl(coverId: number, size: string = 'M'): string {
    if (!coverId) return '';
    return `https://covers.openlibrary.org/b/id/${coverId}-${size}.jpg`;
  }

  addFav(doc: any) {
  const user = this.auth.getCurrentUser();
  if (!user) { 
    this.message = 'Please login to add favorites'; 
    setTimeout(() => {
      this.message = '';
      this.cdr.detectChanges();
    }, 3000);
    return; 
  }
  
  this.fav.add(user.username, { 
    id: doc.key, 
    title: doc.title || this.selectedBook?.title,
    cover_i: doc.cover_i || this.selectedBook?.cover_i, // ADD THIS LINE
    type: 'book' 
  });
  
  this.message = `✓ "${doc.title || this.selectedBook?.title}" added to favorites!`;
  this.cdr.detectChanges();
  setTimeout(() => {
    this.message = '';
    this.cdr.detectChanges();
  }, 3000);
}
}