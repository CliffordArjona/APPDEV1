import { Component, ChangeDetectorRef } from '@angular/core';
import { FavoritesService } from '../favorites-service';
import { AuthService } from '../auth-service';
import { StoryService } from '../story-service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-favourites',
  standalone: false,
  templateUrl: './favourites.html'
})
export class Favourites {
  user: any = null;
  lullaby: any[] = [];
  story: any[] = [];
  
  // Lullaby player state
  showPlayer = false;
  currentTrack: any = null;
  
  // Storybook details state
  selectedBook: any = null;
  loadingDetails = false;

  constructor(
    private fav: FavoritesService, 
    private auth: AuthService,
    private storySvc: StoryService,
    private sanitizer: DomSanitizer,
    private cdr: ChangeDetectorRef
  ) {
    this.user = auth.getCurrentUser();
    if (this.user) this.load();
    window.addEventListener('storage', () => { 
      this.user = auth.getCurrentUser(); 
      if (this.user) this.load(); 
      else { this.lullaby=[]; this.story=[]; }
    });
  }

  load() {
    const data = this.fav.list(this.user.username);
    this.lullaby = data.lullaby || [];
    this.story = data.story || [];
  }

  remove(item: any) {
    this.fav.remove(this.user.username, item);
    this.load();
  }

  // ========== LULLABY PLAYER METHODS ==========
  play(track: any) {
    this.currentTrack = track;
    this.showPlayer = true;
    document.body.style.overflow = 'hidden';
    this.cdr.detectChanges();
  }

  closePlayer() {
    this.showPlayer = false;
    this.currentTrack = null;
    document.body.style.overflow = 'auto';
    this.cdr.detectChanges();
  }

  getSafeUrl(): SafeResourceUrl {
    if (this.currentTrack && this.currentTrack.id) {
      // Extract just the ID part if it's a full path like "/works/OL123W"
      const trackId = this.currentTrack.id.replace('/works/', '').replace('/tracks/', '');
      return this.sanitizer.bypassSecurityTrustResourceUrl(
        `https://open.spotify.com/embed/track/${trackId}`
      );
    }
    return '';
  }

  // ========== STORYBOOK DETAILS METHODS ==========
  viewBook(book: any) {
    console.log('View book clicked:', book.title);
    
    if (!book.id) {
      console.error('No book ID found');
      return;
    }

    // Immediately show loading state
    this.loadingDetails = true;
    this.selectedBook = {
      title: book.title,
      cover_i: book.cover_i,
      key: book.id,
      description: 'Loading...',
      subjects: []
    };
    document.body.style.overflow = 'hidden';
    this.cdr.detectChanges();

    // Small delay to ensure popup shows before loading
    setTimeout(() => {
      this.storySvc.getBookDetails(book.id).subscribe({
        next: details => {
          console.log('Book details received:', details);
          this.loadingDetails = false;
          if (details) {
            this.selectedBook = {
              ...details,
              key: book.id,
              cover_i: book.cover_i
            };
          } else {
            this.selectedBook.description = 'No description available';
          }
          this.cdr.detectChanges();
        },
        error: (err) => {
          console.error('Error loading book details:', err);
          this.loadingDetails = false;
          this.selectedBook.description = 'Error loading details. Please try again.';
          this.cdr.detectChanges();
        }
      });
    }, 100);
  }

  closeBookView() {
    this.selectedBook = null;
    this.loadingDetails = false;
    document.body.style.overflow = 'auto';
    this.cdr.detectChanges();
  }

  getCoverUrl(coverId: number, size: string = 'M'): string {
    if (!coverId) return '';
    return `https://covers.openlibrary.org/b/id/${coverId}-${size}.jpg`;
  }
}