import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Lullaby } from './lullaby';

describe('Lullaby', () => {
  let component: Lullaby;
  let fixture: ComponentFixture<Lullaby>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Lullaby]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Lullaby);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
