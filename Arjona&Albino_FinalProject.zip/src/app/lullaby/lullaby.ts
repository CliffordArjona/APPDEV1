import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { LullabyService } from '../lullaby-service';
import { FavoritesService } from '../favorites-service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { AuthService } from '../auth-service';
import { Router, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-lullaby',
  standalone: false,
  templateUrl: './lullaby.html'
})
export class Lullaby implements OnInit, OnDestroy {
  query = '';
  results: any[] = [];
  message = '';
  loading = false;
  showPlayer = false;
  currentTrack: any = null;
  private routerSubscription?: Subscription;

  constructor(
    private svc: LullabyService, 
    private fav: FavoritesService,
    private sanitizer: DomSanitizer,
    private auth: AuthService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    console.log('Lullaby component initialized');
    this.loadDefaultLullabies();

    // Listen for navigation events to reload when clicking nav again
    this.routerSubscription = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        if (this.router.url === '/lullaby' && this.results.length === 0) {
          console.log('Reloading lullabies from navigation');
          this.loadDefaultLullabies();
        }
      });
  }

  ngOnDestroy() {
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
  }

  loadDefaultLullabies() {
    console.log('Loading default lullabies...');
    this.results = [];
    this.message = '';
    this.loading = true;
    this.cdr.detectChanges(); // Force UI update
    
    this.svc.searchLullabies("children lullaby").subscribe({
      next: (r: any[]) => {
        console.log('Received lullabies:', r.length);
        this.loading = false;
        this.results = r;
        if (r.length === 0) {
          this.message = "Could not load default lullabies. Please try searching.";
        }
        this.cdr.detectChanges(); // Force UI update
      },
      error: (err: any) => {
        console.error('Error loading lullabies:', err);
        this.loading = false;
        this.results = [];
        this.message = "Error loading lullabies. Please try again.";
        this.cdr.detectChanges(); // Force UI update
      }
    });
  }

  search() {
    const trimmedQuery = this.query.trim();
    console.log('Search triggered with query:', trimmedQuery);
    
    if (trimmedQuery.length < 2) {
      this.message = "Type at least 2 characters.";
      this.results = [];
      this.cdr.detectChanges();
      return;
    }
    
    // Immediately clear and show loading
    this.results = [];
    this.message = "";
    this.loading = true;
    this.cdr.detectChanges(); // Force immediate UI update
    
    // Small delay to ensure UI updates before API call
    setTimeout(() => {
      this.svc.searchLullabies(trimmedQuery).subscribe({
        next: (r: any[]) => {
          console.log('Search results received:', r.length);
          this.loading = false;
          this.results = r;
          if (r.length === 0) {
            this.message = "No results found. Try a different search term.";
          }
          this.cdr.detectChanges(); // Force UI update
        },
        error: (err: any) => {
          console.error('Search error:', err);
          this.loading = false;
          this.results = [];
          this.message = "Search failed. Please try again.";
          this.cdr.detectChanges(); // Force UI update
        }
      });
    }, 50);
  }

  addFav(track: any) {
    const user = this.auth.getCurrentUser();
    if (!user) { 
      this.message = 'Please login to add favorites'; 
      setTimeout(() => {
        this.message = '';
        this.cdr.detectChanges();
      }, 3000);
      return; 
    }
    
    this.fav.add(user.username, { 
      id: track.spotifyId, 
      title: track.title,
      author: track.author,
      albumImage: track.albumImage,
      type: 'lullaby' 
    });
    
    this.message = `✓ "${track.title}" added to favorites!`;
    this.cdr.detectChanges();
    setTimeout(() => {
      this.message = '';
      this.cdr.detectChanges();
    }, 3000);
  }

  play(track: any) {
    this.currentTrack = track;
    this.showPlayer = true;
    document.body.style.overflow = 'hidden';
    this.cdr.detectChanges();
  }

  closePlayer() {
    this.showPlayer = false;
    this.currentTrack = null;
    document.body.style.overflow = 'auto';
    this.cdr.detectChanges();
  }

  getSafeUrl(): SafeResourceUrl {
    if (this.currentTrack && this.currentTrack.spotifyId) {
      return this.sanitizer.bypassSecurityTrustResourceUrl(
        `https://open.spotify.com/embed/track/${this.currentTrack.spotifyId}`
      );
    }
    return '';
  }
}