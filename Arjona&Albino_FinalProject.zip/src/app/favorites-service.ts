import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class FavoritesService {
  private key = 'ld_favorites';

  private read(): any {
    const raw = localStorage.getItem(this.key) || '{}';
    try { return JSON.parse(raw); } catch { return {}; }
  }

  private write(map: any) {
    localStorage.setItem(this.key, JSON.stringify(map));
  }

  add(username: string, item: any) {
    const map = this.read();
    map[username] = map[username] || { lullaby: [], story: [] };
    const bucket = item.type === 'book' ? 'story' : 'lullaby';
    if (!map[username][bucket].find((i: any) => i.id === item.id)) {
      map[username][bucket].push(item);
      this.write(map);
    }
  }

  remove(username: string, item: any) {
    const map = this.read();
    if (!map[username]) return;
    const bucket = item.type === 'book' ? 'story' : 'lullaby';
    map[username][bucket] = map[username][bucket].filter((i: any) => i.id !== item.id);
    this.write(map);
  }

  list(username: string) {
    const map = this.read();
    return map[username] || { lullaby: [], story: [] };
  }
}
