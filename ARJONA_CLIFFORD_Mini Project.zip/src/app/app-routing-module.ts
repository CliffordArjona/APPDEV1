import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WaterPokemon } from './water-pokemon/water-pokemon';
import { FirePokemon } from './fire-pokemon/fire-pokemon';
import { GrassPokemon } from './grass-pokemon/grass-pokemon';

const routes: Routes = [
  { path: '', redirectTo: 'water', pathMatch: 'full' },
  { path: 'water', component: WaterPokemon },
  { path: 'fire', component: FirePokemon },
  { path: 'grass', component: GrassPokemon }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
