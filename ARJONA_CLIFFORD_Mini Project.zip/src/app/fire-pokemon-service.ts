import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FirePokemonService {
  getCyndaquil() {
    return {
      name: 'Cyndaquil',
      type: 'Fire',
      hp: 39,
      attack: 52,
      defense: 43,
      spAttack: 60,
      spDefense: 50,
      speed: 65,
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/155.png'
    };
  }

  getQuilava() {
    return {
      name: 'Quilava',
      type: 'Fire',
      hp: 58,
      attack: 64,
      defense: 58,
      spAttack: 80,
      spDefense: 65,
      speed: 80,
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/156.png'
    };
  }

  getTyphlosion() {
    return {
      name: 'Typhlosion',
      type: 'Fire',
      hp: 78,
      attack: 84,
      defense: 78,
      spAttack: 109,
      spDefense: 85,
      speed: 100,
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/157.png'
    };
  }
}
