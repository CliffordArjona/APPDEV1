import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WaterPokemonService {
  getTotodile() {
    return {
      name: 'Totodile',
      type: 'Water',
      hp: 50,
      attack: 65,
      defense: 64,
      spAttack: 44,
      spDefense: 48,
      speed: 43,
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/158.png'
    };
  }

  getCroconaw() {
    return {
      name: 'Croconaw',
      type: 'Water',
      hp: 65,
      attack: 80,
      defense: 80,
      spAttack: 59,
      spDefense: 63,
      speed: 58,
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/159.png'
    };
  }

  getFeraligatr() {
    return {
      name: 'Feraligatr',
      type: 'Water',
      hp: 85,
      attack: 105,
      defense: 100,
      spAttack: 79,
      spDefense: 83,
      speed: 78,
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/160.png'
    };
  }
}
