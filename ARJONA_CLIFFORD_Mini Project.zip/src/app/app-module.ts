import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';

import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { App } from './app';
import { WaterPokemon } from './water-pokemon/water-pokemon';
import { FirePokemon } from './fire-pokemon/fire-pokemon';
import { GrassPokemon } from './grass-pokemon/grass-pokemon';

@NgModule({
  declarations: [
    App,
    WaterPokemon,
    FirePokemon,
    GrassPokemon
  ],
  imports: [
    BrowserModule,
    MatButtonModule,
    MatDividerModule,
    RouterModule.forRoot([
      { path: '', component: WaterPokemon },   
      { path: 'fire', component: FirePokemon },
      { path: 'grass', component: GrassPokemon },
      { path: '**', redirectTo: '' }
    ])
  ],
  providers: [],
  bootstrap: [App]
})
export class AppModule {}
