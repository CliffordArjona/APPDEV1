import { Component } from '@angular/core';
import { GrassPokemonService } from '../grass-pokemon-service';

@Component({
  selector: 'app-grass-pokemon',
  standalone: false,
  templateUrl: './grass-pokemon.html',
  styleUrls: ['./grass-pokemon.css']
})
export class GrassPokemon {
  pokemons: any[] = [];
  currentIndex: number = 0;
  currentPokemon: any;

  constructor(private grassService: GrassPokemonService) {
    this.pokemons = [
      this.grassService.getChikorita(),
      this.grassService.getBayleef(),
      this.grassService.getMeganium()
    ];
    this.currentPokemon = this.pokemons[this.currentIndex];
  }

  evolve() {
    if (this.currentIndex < this.pokemons.length - 1) {
      this.currentIndex++;
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  }

  revert() {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  }
}
