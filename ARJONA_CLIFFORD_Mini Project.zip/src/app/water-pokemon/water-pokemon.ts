import { Component } from '@angular/core';
import { WaterPokemonService } from '../water-pokemon-service';

@Component({
  selector: 'app-water-pokemon',
  standalone: false,
  templateUrl: './water-pokemon.html',
  styleUrls: ['./water-pokemon.css']
})
export class WaterPokemon {
  pokemons: any[] = [];
  currentIndex: number = 0;
  currentPokemon: any;

  constructor(private waterService: WaterPokemonService) {
    this.pokemons = [
      this.waterService.getTotodile(),
      this.waterService.getCroconaw(),
      this.waterService.getFeraligatr()
    ];
    this.currentPokemon = this.pokemons[this.currentIndex];
  }

  evolve() {
    if (this.currentIndex < this.pokemons.length - 1) {
      this.currentIndex++;
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  }

  revert() {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  }
}
