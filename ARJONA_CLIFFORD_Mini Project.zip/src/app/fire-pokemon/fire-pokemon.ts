import { Component } from '@angular/core';
import { FirePokemonService } from '../fire-pokemon-service';

@Component({
  selector: 'app-fire-pokemon',
  standalone: false,
  templateUrl: './fire-pokemon.html',
  styleUrls: ['./fire-pokemon.css']
})
export class FirePokemon {
  pokemons: any[] = [];
  currentIndex: number = 0;
  currentPokemon: any;

  constructor(private fireService: FirePokemonService) {
    this.pokemons = [
      this.fireService.getCyndaquil(),
      this.fireService.getQuilava(),
      this.fireService.getTyphlosion()
    ];
    this.currentPokemon = this.pokemons[this.currentIndex];
  }

  evolve() {
    if (this.currentIndex < this.pokemons.length - 1) {
      this.currentIndex++;
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  }

  revert() {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.currentPokemon = this.pokemons[this.currentIndex];
    }
  }
}
