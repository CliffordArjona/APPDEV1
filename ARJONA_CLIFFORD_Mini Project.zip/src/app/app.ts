import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {
  showPanel = false;

  constructor(private router: Router) {}

  selectStarter(type: string) {
    this.showPanel = true;

    if (type === 'water') this.router.navigate(['/water']);
    if (type === 'fire') this.router.navigate(['/fire']);
    if (type === 'grass') this.router.navigate(['/grass']);
  }

  closePanel() {
    this.showPanel = false;
  }
}
