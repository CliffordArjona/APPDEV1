import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GrassPokemonService {
  getChikorita() {
    return {
      name: 'Chikorita',
      type: 'Grass',
      hp: 45,
      attack: 49,
      defense: 65,
      spAttack: 49,
      spDefense: 65,
      speed: 45,
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/152.png'
    };
  }

  getBayleef() {
    return {
      name: 'Bayleef',
      type: 'Grass',
      hp: 60,
      attack: 62,
      defense: 80,
      spAttack: 63,
      spDefense: 80,
      speed: 60,
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/153.png'
    };
  }

  getMeganium() {
    return {
      name: 'Meganium',
      type: 'Grass',
      hp: 80,
      attack: 82,
      defense: 100,
      spAttack: 83,
      spDefense: 100,
      speed: 80,
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/154.png'
    };
  }
}
